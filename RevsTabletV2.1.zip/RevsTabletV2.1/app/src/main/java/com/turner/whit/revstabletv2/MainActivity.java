package com.turner.whit.revstabletv2;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.design.widget.NavigationView;

import android.support.v4.view.GravityCompat;
import android.support.design.widget.NavigationView;
import android.support.v7.widget.RecyclerView;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;


public class MainActivity extends AppCompatActivity {

//    final String URL_GET_DATA = "https://raw.githubusercontent.com/wtnh/repo/master/jsonformatter%20(8).txt";
    final String URL_GET_DATA = "https://raw.githubusercontent.com/wtnh/repo/master/jsonformatter_10.txt";
    RecyclerView recyclerView;
    static CarAdapter adapter;
    static List<Car> carList;

    private ListView mDrawerList;
    private DrawerLayout mDrawerLayout;
    private ArrayAdapter<String> mAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mActivityTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerList = (ListView)findViewById(R.id.navList);
        mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();

        //Set up the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setBackgroundDrawable(
                new ColorDrawable(Color.parseColor("#273134")));

        //Add items to the drawer menu
        addDrawerItems();
        setupDrawer();

        //Setup the recycler view for the car list
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        carList = new ArrayList<>();

//Call loadCars - this will retrieve the JSON file from URL_GET_DATA location and build array

        loadCars();

    }



    private void addDrawerItems() {
        final String[] str = {"Training Materials", "Emergency Procedures", "Museum Information", "Volunteer Docs", "Revs Website", "Volgistics", "Digital Library",
        "Tappet Clatter Archives", "Videos"};
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, str);
        mDrawerList.setAdapter(mAdapter);

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this, "You clicked menu item id number " +id, Toast.LENGTH_SHORT).show();
                Bundle bundle = new Bundle();
                String url = null;
                switch (position) {
                    case 0:

                        url = "https://revsinstitute.box.com/s/qmiqh458ahkqgp7ivg2x6c1qz9mb6cje";

                    break;

                    case 1:

                        url = "https://revsinstitute.box.com/s/qmiqh458ahkqgp7ivg2x6c1qz9mb6cje";

                    break;

                    case 2:

                        url = "https://revsinstitute.box.com/s/qmiqh458ahkqgp7ivg2x6c1qz9mb6cje";

                    break;

                    case 3:

                        url = "https://revsinstitute.app.box.com/s/vvbgsfzfas3pthsgs7nq";

                    case 4:

                        url = "https://revsinstitute.org";

                    break;

                    case 5:

                        url = "https://www.volgistics.com/ex2/vicnet.dll?FROM=110030";

                    break;

                    case 6:

                        url = "https://www.volgistics.com/ex2/vicnet.dll?FROM=110030";

                    break;

                    case 7:

                        url = "https://revsinstitute.box.com/s/h5pttf8nmif3stwbu1yyvjar3hba5grq";

                    break;

                }

                bundle.putString("urlString", url);
                Intent intent = new Intent(MainActivity.this, WebActivity5.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    private void setupDrawer() {
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {
            /**
             * Called when a drawer has settled in a completely open state.
             */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle("Menu");
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
            /**
             * Called when a drawer has settled in a completely closed state.
             */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.addDrawerListener(mDrawerToggle);

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);


// Set up a drop down spinner in actionbar for sorting the car list - sort values in res/values/array.xml
// Spinner text color is set in res/layout/spinner_item.xml

        MenuItem item = menu.findItem(R.id.spinner);

        Spinner spinner = (Spinner) item.getActionView();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_list_item_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_item);

        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                int index = parent.getSelectedItemPosition();

                String selectedItem = parent.getItemAtPosition(pos).toString();

                switch (selectedItem)
                {
                    case "Sort by Station":
                        sortArrayListStation();
                break;

                    case "Sort by Year":
                        sortArrayListYear();
                break;

                    case "Sort by Make":
                        sortArrayListMake();

                break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        // Activate the navigation drawer toggle
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


//Resort the carList according to the choice in the spinner drop-down
    private void sortArrayListYear() {
        Collections.sort(carList, new Comparator<Car>() {
            @Override
            public int compare(Car o1, Car o2) {
                return o1.getYear().compareTo(o2.getYear());

            }
        });

        adapter.notifyDataSetChanged();

    }

    private void sortArrayListMake() {
        Collections.sort(carList, new Comparator<Car>() {
            @Override
            public int compare(Car o1, Car o2) {
                return o1.getMake().compareTo(o2.getMake());
            }
        });

        adapter.notifyDataSetChanged();
    }

    private static void sortArrayListStation() {
        Collections.sort(carList, new Comparator<Car>() {
            @Override
            public int compare(Car o1, Car o2) {
                return o1.getStation().compareTo(o2.getStation());
            }
        });

        adapter.notifyDataSetChanged();
    }

    private void loadCars() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_GET_DATA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);

                                Car car = new Car(
                                        obj.getString("id"),
                                        obj.getString("make"),
                                        obj.getString("model"),
                                        obj.getString("year"),
                                        obj.getString("thumburl"),
                                        obj.getString("descr"),
                                        obj.getString("country"),
                                        obj.getString("gallery"),
                                        obj.getString("gallery_seq"),
                                        obj.getInt("station"),
                                        obj.getString("fact1"),
                                        obj.getString("fact2"),
                                        obj.getString("fact3"),
                                        obj.getString("fact4"),
                                        obj.getString("fact5"),
                                        obj.getString("fact6"),
                                        obj.getString("fact7"),
                                        obj.getString("fact8"),
                                        obj.getString("articlesurl"),
                                        obj.getString("dashurl"),
                                        obj.getString("imagesurl"),
                                        obj.getString("tcurl"),
                                        obj.getString("aacurl"),
                                        obj.getString("spare")

                                );

                                carList.add(car);
                            }

                            adapter = new CarAdapter(carList, getApplicationContext());
                            recyclerView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
