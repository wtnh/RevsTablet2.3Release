package com.turner.whit.revstabletv2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

import com.bumptech.glide.Glide;

import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder> {

    private List<Car> carList;
    private Context context;


    //temporarily setting current position off screen so initial expanded card is not shown
    //todo change visibility toggle logic to set gone on all items on data change

    private static int currentPosition = -1;

    public CarAdapter(List<Car> carList, Context context) {
        this.carList = carList;
        this.context = context;
//        this.setHasStableIds(true);
    }

    @Override
    public CarViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_layout_cars, parent, false);
        return new CarViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final CarViewHolder holder, final int position) {

        final Car car = carList.get(position);

        Toast.makeText(context, "onBindViewHolder fired; position is: " + currentPosition, Toast.LENGTH_SHORT).show();

        holder.textViewYear.setText(car.getYear());
        holder.textViewMake.setText(car.getMake());
        holder.textViewModel.setText(car.getModel());
        holder.textViewDescr.setText(car.getDescr());
        holder.textViewFact1.setText(car.getFact1());
        holder.textViewFact2.setText(car.getFact2());
        holder.textViewFact3.setText(car.getFact3());
        holder.textViewFact4.setText(car.getFact4());
        holder.textViewFact5.setText(car.getFact5());
        holder.textViewFact6.setText(car.getFact6());
        holder.textViewFact7.setText(car.getFact7());
        holder.textViewFact8.setText(car.getFact8());

        Glide.with(context).load(car.getThumburl()).into(holder.imageViewThumb);

        //launch articles when button clicked

        holder.btnArticles.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
            String url= car.getArticlesurl();
            Bundle bundle = new Bundle();
            bundle.putString("urlString",url);
            Intent intent = new Intent(context, WebActivity5.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtras(bundle);
            context.startActivity(intent);

            }
        });

        //launch dash photos

        holder.btnDash.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String url=car.getDashurl();
                Bundle bundle = new Bundle();
                bundle.putString("urlString",url);
                Intent intent = new Intent(context, WebActivity5.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

        //launch photo folder

        holder.btnPhotos.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String url=car.getImagesurl();
                Bundle bundle = new Bundle();
                bundle.putString("urlString",url);
                Intent intent = new Intent(context, WebActivity5.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });


        holder.linearLayout.setVisibility(View.GONE);

        holder.imageViewArrow.setImageResource(R.drawable.ic_expand_more_white_12dp);

        //if the position is equal to the item position which is to be expanded
        if (currentPosition == position) {
            //creating an animation
            Animation slideDown = AnimationUtils.loadAnimation(context, R.anim.slide_down);

            //toggling visibility
            holder.linearLayout.setVisibility(View.VISIBLE);

            holder.imageViewArrow.setImageResource(R.drawable.ic_expand_less_white_12dp);

            //adding sliding effect
            holder.linearLayout.startAnimation(slideDown);
        }

        holder.imageViewArrow.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                //getting the position of the item to expand it if not visible
                currentPosition = position;

                if (holder.linearLayout.getVisibility() == View.VISIBLE) {

                    // Its visible, so toggle visibility

                    holder.linearLayout.setVisibility(View.GONE);

                    holder.imageViewArrow.setImageResource(R.drawable.ic_expand_more_white_12dp);

                    //reset current position to -1 so that all cards are collapsed

                    currentPosition = -1;

                    //reload the list

                } else notifyDataSetChanged();

            }
        });
    }

    @Override
    public int getItemCount() {
        return carList.size();
    }

    class CarViewHolder extends RecyclerView.ViewHolder {
        TextView textViewYear, textViewMake, textViewModel, textViewDescr, textViewFact1, textViewFact2, textViewFact3, textViewFact4, textViewFact5, textViewFact6,
        textViewFact7, textViewFact8;
        ImageView imageViewThumb; ImageView imageViewArrow; Button btnArticles; Button btnDash; Button btnPhotos;
        LinearLayout linearLayout;


        CarViewHolder(View itemView) {
            super(itemView);

            btnArticles = itemView.findViewById(R.id.Button2);
            btnDash = itemView.findViewById(R.id.Button1);
            btnPhotos = itemView.findViewById(R.id.Button3);

            textViewYear = itemView.findViewById(R.id.textViewYear);
            textViewMake = itemView.findViewById(R.id.textViewMake);
            textViewModel = itemView.findViewById(R.id.textViewModel);
            textViewDescr = itemView.findViewById(R.id.textViewDescr);

            textViewFact1 = itemView.findViewById(R.id.textViewFact1);
            textViewFact2 = itemView.findViewById(R.id.textViewFact2);
            textViewFact3 = itemView.findViewById(R.id.textViewFact3);
            textViewFact4 = itemView.findViewById(R.id.textViewFact4);
            textViewFact5 = itemView.findViewById(R.id.textViewFact5);
            textViewFact6 = itemView.findViewById(R.id.textViewFact6);
            textViewFact7 = itemView.findViewById(R.id.textViewFact7);
            textViewFact8 = itemView.findViewById(R.id.textViewFact8);

            imageViewArrow = itemView.findViewById(R.id.imageViewArrow);

            imageViewThumb = itemView.findViewById(R.id.imageViewThumb);

            linearLayout = itemView.findViewById(R.id.linearLayout);
        }
    }
}
